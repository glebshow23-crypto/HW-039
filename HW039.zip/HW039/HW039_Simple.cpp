#include "HW039_Simple.h"

HW039_Simple::HW039_Simple(uint8_t rpwm_pin, uint8_t lpwm_pin) 
    : _rpwm_pin(rpwm_pin), _lpwm_pin(lpwm_pin) {
}

void HW039_Simple::begin() {
    pinMode(_rpwm_pin, OUTPUT);
    pinMode(_lpwm_pin, OUTPUT);
    
    // Убедимся, что мотор остановлен при инициализации
    stop();
    
    // Настройка частоты ШИМ для тихой работы (если поддерживается платой)
    #if defined(ESP32)
        ledcAttachPin(_rpwm_pin, 0);
        ledcAttachPin(_lpwm_pin, 1);
        ledcSetup(0, 20000, 8); // 20 kHz, 8 бит
        ledcSetup(1, 20000, 8);
    #elif defined(ESP8266)
        analogWriteFreq(20000); // 20 kHz
    #elif defined(__AVR__)
        // Для Arduino UNO/Nano пины 5,6 имеют ~980Hz, другие ~490Hz
        // Можно изменить через таймеры, но это сложнее
    #endif
}

void HW039_Simple::go(int8_t direction, uint8_t speed) {
    // Ограничиваем скорость
    speed = constrain(speed, 0, 255);
    
    // Игнорируем скорости ниже минимальной (кроме 0)
    if (speed > 0 && speed < _min_speed) {
        speed = _min_speed;
    }
    
    if (direction > 0) {
        // Вращение вперед
        analogWrite(_rpwm_pin, speed);
        analogWrite(_lpwm_pin, 0);
    } 
    else if (direction < 0) {
        // Вращение назад
        analogWrite(_rpwm_pin, 0);
        analogWrite(_lpwm_pin, speed);
    } 
    else {
        // Остановка
        stop();
    }
}

void HW039_Simple::goPercent(int8_t speed_percent) {
    // speed_percent: -100..100
    speed_percent = constrain(speed_percent, -100, 100);
    
    if (speed_percent > 0) {
        uint8_t speed = map(abs(speed_percent), 0, 100, _min_speed, 255);
        go(1, speed);
    }
    else if (speed_percent < 0) {
        uint8_t speed = map(abs(speed_percent), 0, 100, _min_speed, 255);
        go(-1, speed);
    }
    else {
        stop();
    }
}

void HW039_Simple::goSmooth(int8_t direction, uint8_t target_speed, uint16_t ramp_time) {
    target_speed = constrain(target_speed, 0, 255);
    
    // Текущие значения ШИМ
    uint8_t current_rpwm = 0;
    uint8_t current_lpwm = 0;
    
    // Определяем целевые значения
    uint8_t target_rpwm = (direction > 0) ? target_speed : 0;
    uint8_t target_lpwm = (direction < 0) ? target_speed : 0;
    
    // Время одного шага (примерно)
    uint16_t step_delay = ramp_time / target_speed;
    
    // Плавный разгон
    for (uint8_t i = 0; i <= target_speed; i++) {
        if (direction > 0) {
            analogWrite(_rpwm_pin, i);
            analogWrite(_lpwm_pin, 0);
        } else {
            analogWrite(_rpwm_pin, 0);
            analogWrite(_lpwm_pin, i);
        }
        delayMicroseconds(step_delay * 100);
    }
}

void HW039_Simple::stop() {
    analogWrite(_rpwm_pin, 0);
    analogWrite(_lpwm_pin, 0);
}

void HW039_Simple::brake() {
    // Для активного торможения подаем HIGH на оба входа
    digitalWrite(_rpwm_pin, HIGH);
    digitalWrite(_lpwm_pin, HIGH);
    delay(100); // Короткий импульс
    stop(); // Затем отключаем
}
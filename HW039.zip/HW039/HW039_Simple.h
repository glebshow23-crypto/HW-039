#ifndef HW039_SIMPLE_H
#define HW039_SIMPLE_H

#include <Arduino.h>

class HW039_Simple {
public:
    // Конструктор - только RPWM и LPWM пины
    HW039_Simple(uint8_t rpwm_pin, uint8_t lpwm_pin);
    
    // Инициализация
    void begin();
    
    // Основная функция управления
    // direction: 1 = вперед, -1 = назад, 0 = стоп
    // speed: 0-255 (0 = стоп, 255 = макс скорость)
    void go(int8_t direction, uint8_t speed);
    
    // Альтернативный метод управления скоростью -100..100
    void goPercent(int8_t speed_percent);
    
    // Плавное изменение скорости
    void goSmooth(int8_t direction, uint8_t speed, uint16_t ramp_time = 500);
    
    // Немедленная остановка (обнуление ШИМ)
    void stop();
    
    // Торможение (активная блокировка)
    void brake();
    
    // Установить минимальную скорость (deadzone)
    void setMinSpeed(uint8_t min_speed) { _min_speed = min_speed; }
    
private:
    uint8_t _rpwm_pin;
    uint8_t _lpwm_pin;
    uint8_t _min_speed = 0;
};

#endif